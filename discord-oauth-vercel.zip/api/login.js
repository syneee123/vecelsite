export default function handler(req, res) {
  const CLIENT_ID = "SEU_CLIENT_ID";
  const REDIRECT_URI = "https://cpxstoreauth.vercel.app/callback";

  const discordAuthUrl = `https://discord.com/oauth2/authorize?client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=identify`;

  res.redirect(discordAuthUrl);
}