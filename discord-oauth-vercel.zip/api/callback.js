import fetch from "node-fetch";

export default async function handler(req, res) {
  const code = req.query.code;
  const CLIENT_ID = "SEU_CLIENT_ID";
  const CLIENT_SECRET = "SEU_CLIENT_SECRET";
  const REDIRECT_URI = "https://cpxstoreauth.vercel.app/callback";

  if (!code) return res.status(400).send("Código não recebido.");

  const params = new URLSearchParams();
  params.append("client_id", CLIENT_ID);
  params.append("client_secret", CLIENT_SECRET);
  params.append("grant_type", "authorization_code");
  params.append("code", code);
  params.append("redirect_uri", REDIRECT_URI);
  params.append("scope", "identify");

  try {
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      body: params,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    });

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      return res.status(400).json(tokenData);
    }

    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`
      }
    });

    const userData = await userResponse.json();

    res.status(200).json({ tokenData, userData });

  } catch (err) {
    res.status(500).send("Erro no login: " + err.message);
  }
}