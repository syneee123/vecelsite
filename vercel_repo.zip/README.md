# Vercel Site

Site simples para callback do Discord OAuth.